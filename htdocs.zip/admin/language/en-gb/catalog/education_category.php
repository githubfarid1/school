<?php
// Heading
$_['heading_title']          = 'Education Category';

// Text
$_['text_success']           = 'Success: You have modified Education Categories!';
$_['text_list']              = 'Education Category List';
$_['text_education'] = 'Education Name';
$_['text_main_field'] = 'Main Column';
$_['text_filter'] = 'Filters';
$_['text_attribute'] = 'Attributes';

?>
